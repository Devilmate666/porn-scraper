export interface Env {
  CACHE: KVNamespace;
  SCRAPE_DATA: KVNamespace;
  CLOUDFLARE_API_TOKEN?: string;
  CLOUDFLARE_ACCOUNT_ID?: string;
  /** "live" (default) = the Worker scrapes first, KV fallback.  "kv" = KV first. */
  MODE?: string;
  /** "on" (default): the Worker scrapes the websites itself. "off": KV only. */
  LIVE_SCRAPE?: string;
  /** Extra hosts the Worker may scrape on request, comma separated (the 4 built-in sources + scraper catalog are always allowed). */
  ALLOWED_HOSTS?: string;
  /** "1" = allow any public host (disables the allowlist). */
  ALLOW_ANY?: string;
  /** Max native scrapes per client IP per minute (default 90). */
  RATE_PER_MIN?: string;
  /** Chaturbate affiliate campaign slug for the fallback endpoint (default "dvafl"). */
  CHATURBATE_WM?: string;
  /** Comma list of direct cam platforms to fetch, default "chaturbate,stripchat,cam4,camsoda". */
  CAM_PROVIDERS?: string;
  /** Watchdog: lets the Worker's cron start the GitHub scraper workflow when data is stale. */
  GITHUB_TOKEN?: string;      // fine-grained PAT with Actions: read & write (set as secret)
  GITHUB_REPO?: string;       // "owner/name"
  GITHUB_REF?: string;        // default "main"
  GITHUB_WORKFLOW?: string;   // default "scrape-live.yml"
}
